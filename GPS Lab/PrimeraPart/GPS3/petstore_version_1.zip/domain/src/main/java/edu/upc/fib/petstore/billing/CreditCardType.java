package edu.upc.fib.petstore.billing;

public enum CreditCardType {
    VISA("Visa"), mastercard("MasterCard"), amex("American Express");

    private final String commonName;

    CreditCardType(String commonName) {
        this.commonName = commonName;
    }

    public String commonName() {
        return commonName;
    }

    public String toString() {
        return name();
    }
}

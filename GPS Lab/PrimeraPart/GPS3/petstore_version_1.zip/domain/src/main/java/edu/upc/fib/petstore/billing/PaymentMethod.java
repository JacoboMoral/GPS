package edu.upc.fib.petstore.billing;

public abstract class PaymentMethod {

	@SuppressWarnings("unused")
    private long id;
}

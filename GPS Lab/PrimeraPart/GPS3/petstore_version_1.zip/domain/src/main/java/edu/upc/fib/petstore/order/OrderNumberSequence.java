package edu.upc.fib.petstore.order;

public interface OrderNumberSequence {

    OrderNumber nextOrderNumber();
}

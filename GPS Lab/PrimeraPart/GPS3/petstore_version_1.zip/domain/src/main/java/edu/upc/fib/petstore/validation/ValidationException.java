package edu.upc.fib.petstore.validation;


/**
 * Validation exception
 * @author gps
 */
public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }

    private static final long serialVersionUID = 1L;
}
package edu.upc.fib.petstore.product;

public interface AttachmentStorage {

    String getLocation(String fileName);
}

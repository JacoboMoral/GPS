package edu.upc.fib.petstore.order;

import edu.upc.fib.petstore.billing.PaymentMethod;
import edu.upc.fib.petstore.transaction.QueryUnitOfWork;
import edu.upc.fib.petstore.transaction.Transactor;
import edu.upc.fib.petstore.validation.Ensure;

public class Cashier implements SalesAssistant {
    private final OrderNumberSequence orderNumberSequence;
    private final OrderBook orderBook;
    private final Transactor transactor;

    public Cashier(OrderNumberSequence orderNumberSequence, OrderBook orderBook, Transactor transactor) {
        this.orderNumberSequence = orderNumberSequence;
        this.orderBook = orderBook;
        this.transactor = transactor;
    }

    public OrderNumber placeOrder(final Cart cart, final PaymentMethod paymentMethod) throws Exception {
        Ensure.valid(paymentMethod);
        QueryUnitOfWork<OrderNumber> confirmation = new QueryUnitOfWork<OrderNumber>() {
            public OrderNumber query() throws Exception {
                OrderNumber nextNumber = orderNumberSequence.nextOrderNumber();
                final Order order = new Order(nextNumber);
                order.addItemsFrom(cart);
                order.pay(paymentMethod);
                orderBook.record(order);
                cart.clear();
                return nextNumber;
            }
        };
        return transactor.performQuery(confirmation);
    }
}

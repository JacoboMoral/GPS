package edu.upc.fib.petstore.transaction;

public interface UnitOfWork {

    void execute() throws Exception;
}

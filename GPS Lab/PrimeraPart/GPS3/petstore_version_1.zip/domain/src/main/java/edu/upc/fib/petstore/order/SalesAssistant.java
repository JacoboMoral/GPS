package edu.upc.fib.petstore.order;

import edu.upc.fib.petstore.billing.PaymentMethod;

public interface SalesAssistant {

    OrderNumber placeOrder(Cart cart, PaymentMethod paymentMethod) throws Exception;
}

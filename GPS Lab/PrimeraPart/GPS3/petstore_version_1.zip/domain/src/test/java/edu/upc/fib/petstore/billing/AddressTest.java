package edu.upc.fib.petstore.billing;


import static edu.upc.fib.petstore.builders.support.AddressBuilder.anAddress;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;

import org.junit.Test;

public class AddressTest {

    String MISSING = null;


    @Test public void
    isInvalidWithoutAFirstName() {    	
        assertThat("validació adreça sense nom", anAddress().withFirstName(MISSING).build().getFirstName(), is(nullValue()));
    }
    
    @Test public void
    isInvalidWithoutALastName() { 
        assertThat("validació adreça sense cognom", anAddress().withLastName(MISSING).build().getLastName(), is(nullValue()));
    }

    @Test public void
    isValidWithAFullName() {
    	Address adreça = anAddress().build();
    	    
    	assertThat(adreça.getFirstName(), is(not(nullValue())));
    	assertThat(adreça.getLastName(), is(not(nullValue())));
    	        
    }
}

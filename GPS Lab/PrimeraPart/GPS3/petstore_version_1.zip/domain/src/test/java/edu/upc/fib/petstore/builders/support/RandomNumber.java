package edu.upc.fib.petstore.builders.support;

import static java.lang.String.valueOf;

import java.util.Random;

public class RandomNumber {

    private final int maxValue;
    private final Random random;

    public RandomNumber(int maxValue) {
        this.maxValue = maxValue;
        random = new Random();
    }

    public String generate() {
        return valueOf(random.nextInt(maxValue));
    }
}

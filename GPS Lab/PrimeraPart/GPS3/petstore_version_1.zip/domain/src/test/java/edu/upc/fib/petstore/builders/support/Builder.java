package edu.upc.fib.petstore.builders.support;

public interface Builder<T> {
    T build();
}

package edu.upc.fib.petstore.builders.support;

import edu.upc.fib.petstore.billing.Address;

public class AddressBuilder implements Builder<Address> {

    private String firstName = "Xavier";
    private String lastName = "Escudero";
    private String emailAddress = "javier.escudero@upc.edu";

    public static AddressBuilder anAddress() {
        return new AddressBuilder();
    }

    public AddressBuilder withFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public AddressBuilder withLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public AddressBuilder withEmail(String emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    public Address build() {
        return new Address(firstName, lastName, emailAddress);
    }
}
package edu.upc.fib.petstore.db.records;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.vtence.tape.Record;

import edu.upc.fib.petstore.db.Access;

public abstract class AbstractRecord<T> implements Record<T> {

    public void handleKeys(ResultSet keys, T entity) throws SQLException {
        Access.idOf(entity).set(generatedId(keys));
    }

    private long generatedId(ResultSet rs) throws SQLException {
        rs.first();
        return rs.getLong(1);
    }
}

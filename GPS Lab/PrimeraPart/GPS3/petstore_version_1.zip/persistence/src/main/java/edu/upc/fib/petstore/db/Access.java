package edu.upc.fib.petstore.db;

import edu.upc.fib.petstore.order.Order;
import edu.upc.fib.petstore.product.Product;

public class Access {

    public static FieldAccessor<Long> idOf(Object entity) {
        return FieldAccessor.access(entity, "id");
    }

    public static FieldAccessor<Product> productOf(Object entity) {
        return FieldAccessor.access(entity, "product");
    }

    public static FieldAccessor<Order> orderOf(Object entity) {
        return FieldAccessor.access(entity, "order");
    }

    private Access() {}
}



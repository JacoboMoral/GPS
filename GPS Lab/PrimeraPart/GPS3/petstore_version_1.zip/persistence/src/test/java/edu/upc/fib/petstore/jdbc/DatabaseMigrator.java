package edu.upc.fib.petstore.jdbc;

import javax.sql.DataSource;

import com.googlecode.flyway.core.Flyway;

public class DatabaseMigrator {

    private final Flyway flyway;

    public DatabaseMigrator(DataSource dataSource) {
        flyway = new Flyway();
        flyway.setDataSource(dataSource);
        flyway.setSqlMigrationPrefix("");
    }

    public void migrate() {
    	//flyway.clean();
        flyway.migrate();
    }
}

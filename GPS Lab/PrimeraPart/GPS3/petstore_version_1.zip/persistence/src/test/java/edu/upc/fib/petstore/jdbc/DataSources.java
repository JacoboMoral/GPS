package edu.upc.fib.petstore.jdbc;

import javax.sql.DataSource;

import com.vtence.tape.DriverManagerDataSource;

public class DataSources {

    public static DataSource local() {
        return new DriverManagerDataSource(
                "jdbc:mysql://localhost:3306/petstore_test?generateSimpleParameterMetadata=true",
                "testbot",
                "petstore");
    }
}

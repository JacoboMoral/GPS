package edu.upc.fib.petstore.web;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

public class WebRoot {

    public static Path currentRelativePath = Paths.get("");
    public static final String RELATIVE_WEB_APP_PATH = currentRelativePath.toAbsolutePath().toString();

    public static File locate() {
        return new File(RELATIVE_WEB_APP_PATH);
    }

    public static File layouts() {
        return new File(WebRoot.locate(), "src" + File.separator + "main" + File.separator + "content" + File.separator + "views" + File.separator + "layouts");
    }

    public static File pages() {
        return new File(WebRoot.locate(), "src" + File.separator + "main" + File.separator + "content" + File.separator + "views" + File.separator + "pages");
    }
}

package edu.upc.fib.petstore.web;

public interface Messages {

    String interpolate(String error, Object... parameters);
}

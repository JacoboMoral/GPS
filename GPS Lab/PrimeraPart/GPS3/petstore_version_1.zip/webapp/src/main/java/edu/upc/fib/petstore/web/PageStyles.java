package edu.upc.fib.petstore.web;

import java.io.File;

import com.vtence.molecule.templating.JMustacheRenderer;
import com.vtence.molecule.templating.Template;
import com.vtence.molecule.templating.Templates;

import edu.upc.fib.petstore.web.views.PlainPage;

public class PageStyles {

    private final Templates templates;

    public PageStyles(File inDir) {
        this.templates = new Templates(new JMustacheRenderer().encoding("utf-8")
                                                              .fromDir(inDir)
                                                              .extension("html")
                                                              .defaultValue(""));
    }

    public Template<PlainPage> main() {
        return templates.named("main");
    }
}

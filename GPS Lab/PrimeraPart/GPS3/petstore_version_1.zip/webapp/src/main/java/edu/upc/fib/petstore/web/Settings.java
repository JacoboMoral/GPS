package edu.upc.fib.petstore.web;

import edu.upc.fib.petstore.web.lib.Configuration;

public class Settings {
    public final String databaseUrl;
    public final String databaseUsername;
    public final String databasePassword;

    public Settings(Configuration config) {
        databaseUrl = config.get("jdbc.url");
        databaseUsername = config.get("jdbc.username");
        databasePassword = config.get("jdbc.password");
    }
}

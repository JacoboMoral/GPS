package edu.upc.fib.petstore.web.controllers;

import java.util.List;

import com.vtence.molecule.Application;
import com.vtence.molecule.Request;
import com.vtence.molecule.Response;

import edu.upc.fib.petstore.product.Item;
import edu.upc.fib.petstore.product.ItemInventory;
import edu.upc.fib.petstore.web.View;
import edu.upc.fib.petstore.web.views.AvailableItems;

public class ListItems implements Application {

    private final ItemInventory itemInventory;
    private final View<AvailableItems> view;

    public ListItems(ItemInventory itemInventory, View<AvailableItems> view) {
        this.itemInventory = itemInventory;
        this.view = view;
    }

    public void handle(Request request, Response response) throws Exception {
        String productNumber = request.parameter("product");
        List<Item> found = itemInventory.findByProductNumber(productNumber);
        view.render(response, new AvailableItems().add(found));
    }
}
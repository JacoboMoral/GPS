package edu.upc.fib.petstore.web.controllers;

import java.util.List;

import com.vtence.molecule.Application;
import com.vtence.molecule.Request;
import com.vtence.molecule.Response;

import edu.upc.fib.petstore.product.AttachmentStorage;
import edu.upc.fib.petstore.product.Product;
import edu.upc.fib.petstore.product.ProductCatalog;
import edu.upc.fib.petstore.web.View;
import edu.upc.fib.petstore.web.views.Products;

public class ListProducts implements Application {

    private final ProductCatalog productCatalog;
    private final AttachmentStorage attachmentStorage;
    private final View<Products> view;

    public ListProducts(ProductCatalog productCatalog, AttachmentStorage attachmentStorage, View<Products> view) {
        this.productCatalog = productCatalog;
        this.attachmentStorage = attachmentStorage;
        this.view = view;
    }

    public void handle(Request request, Response response) throws Exception {
        String keyword = request.parameter("keyword");
        List<Product> found = productCatalog.findByKeyword(keyword);
        view.render(response, new Products().matching(keyword)
                                                    .add(found)
                                                    .withPhotosIn(attachmentStorage));
    }
}
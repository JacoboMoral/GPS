package edu.upc.fib.petstore.web.lib;

import static edu.upc.fib.petstore.billing.CreditCardType.valueOf;

import com.vtence.molecule.Request;

import edu.upc.fib.petstore.billing.Address;
import edu.upc.fib.petstore.billing.CreditCardDetails;
import edu.upc.fib.petstore.billing.CreditCardType;
import edu.upc.fib.petstore.validation.Valid;
import edu.upc.fib.petstore.validation.Validates;

public class PaymentForm extends Form {

    public static PaymentForm parse(Request request) {
        return new PaymentForm(new CreditCardDetails(
                valueOf(request.parameter("card-type")),
                request.parameter("card-number"),
                request.parameter("expiry-date"),
                new Address(
                        request.parameter("first-name"),
                        request.parameter("last-name"),
                        request.parameter("email"))));
    }

    private final Valid<CreditCardDetails> paymentDetails;

    public PaymentForm(CreditCardDetails paymentDetails) {
        this.paymentDetails = Validates.validityOf(paymentDetails);
    }

    public CreditCardType cardType() {
        return paymentDetails().getCardType();
    }

    public CreditCardDetails paymentDetails() {
        return paymentDetails.get();
    }
}

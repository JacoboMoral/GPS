package edu.upc.fib.petstore.web.lib;

import java.util.HashSet;
import java.util.Set;

import edu.upc.fib.petstore.validation.ConstraintViolation;
import edu.upc.fib.petstore.validation.Validator;
import edu.upc.fib.petstore.web.Messages;

public abstract class Form {

    private final Set<ConstraintViolation<?>> violations = new HashSet<>();

    public boolean validate(Validator validator) {
        violations.addAll(validator.validate(this));
        return violations.isEmpty();
    }

    public ErrorMessages errors(Messages messages) {
        ErrorMessages errors = new ErrorMessages();
        for (ConstraintViolation<?> violation : violations) {
            errors.add(violation.path(), translate(messages, violation.path(), violation.error()));
        }
        return errors;
    }

    private String translate(Messages messages, String path, String error) {
        return messages.interpolate(error + "." + path);
    }
}

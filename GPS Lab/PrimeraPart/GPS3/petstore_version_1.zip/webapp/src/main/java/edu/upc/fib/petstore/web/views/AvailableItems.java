package edu.upc.fib.petstore.web.views;

import java.util.ArrayList;
import java.util.Collection;

import edu.upc.fib.petstore.product.Item;

public class AvailableItems {

    private final Collection<Item> items = new ArrayList<>();

    public AvailableItems() {}

    public AvailableItems add(Collection<Item> available) {
        items.addAll(available);
        return this;
    }

    public Iterable<Item> getEach() {
        return items;
    }

    public boolean isNone() {
        return items.isEmpty();
    }

    public int getCount() {
        return items.size();
    }
}
package edu.upc.fib.petstore.web.controllers;

import java.math.BigDecimal;

import com.vtence.molecule.Application;
import com.vtence.molecule.Request;
import com.vtence.molecule.Response;

import edu.upc.fib.petstore.web.View;
import edu.upc.fib.petstore.web.lib.SessionScope;
import edu.upc.fib.petstore.web.views.Checkout;

public class ProceedToCheckout implements Application {
    private final View<Checkout> view;

    public ProceedToCheckout(View<Checkout> view) {
        this.view = view;
    }

    public void handle(Request request, Response response) throws Exception {
        view.render(response, new Checkout().forTotalOf(currentCartTotal(request)));
    }

    private BigDecimal currentCartTotal(Request request) {
        return SessionScope.cart(request).getGrandTotal();
    }
}

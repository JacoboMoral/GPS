package edu.upc.fib.petstore.web.controllers;

import java.io.IOException;
import java.math.BigDecimal;

import com.vtence.molecule.Application;
import com.vtence.molecule.Request;
import com.vtence.molecule.Response;

import edu.upc.fib.petstore.order.OrderNumber;
import edu.upc.fib.petstore.order.SalesAssistant;
import edu.upc.fib.petstore.validation.Validator;
import edu.upc.fib.petstore.web.Messages;
import edu.upc.fib.petstore.web.View;
import edu.upc.fib.petstore.web.lib.PaymentForm;
import edu.upc.fib.petstore.web.lib.SessionScope;
import edu.upc.fib.petstore.web.views.Checkout;

public class PlaceOrder implements Application {
    private final SalesAssistant salesAssistant;
    private final View<Checkout> checkoutView;
    private final Messages messages;
    private final Validator validator = new Validator();

    public PlaceOrder(SalesAssistant salesAssistant, View<Checkout> checkoutView, Messages messages) {
        this.salesAssistant = salesAssistant;
        this.checkoutView = checkoutView;
        this.messages = messages;
    }

    public void handle(Request request, Response response) throws Exception {
        PaymentForm form = PaymentForm.parse(request);
        if (valid(form)) {
            processOrder(request, response, form);
        } else {
            rejectOrder(request, response, form);
        }
    }

    private boolean valid(PaymentForm form) {
        return form.validate(validator);
    }

    private void processOrder(Request request, Response response, PaymentForm form) throws Exception {
        OrderNumber orderNumber = salesAssistant.placeOrder(SessionScope.cart(request), form.paymentDetails());
        response.redirectTo("/orders/" + orderNumber.getNumber()).done();
    }

    private void rejectOrder(Request request, Response response, PaymentForm form) throws IOException {
        checkoutView.render(response, new Checkout().
                forTotalOf(currentCartTotal(request)).
                withPayment(form.paymentDetails()).
                withErrors(form.errors(messages)));
    }

    private BigDecimal currentCartTotal(Request request) {
        return SessionScope.cart(request).getGrandTotal();
    }
}
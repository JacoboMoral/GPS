package edu.upc.fib.petstore.web;

import java.io.File;

import com.vtence.molecule.templating.JMustacheRenderer;
import com.vtence.molecule.templating.Template;
import com.vtence.molecule.templating.Templates;

import edu.upc.fib.petstore.order.Cart;
import edu.upc.fib.petstore.order.Order;
import edu.upc.fib.petstore.web.views.AvailableItems;
import edu.upc.fib.petstore.web.views.Checkout;
import edu.upc.fib.petstore.web.views.Products;

public class Pages {

    private final Templates templates;

    public Pages(File inDir) {
        this.templates = new Templates(new JMustacheRenderer().encoding("utf-8")
                                                              .fromDir(inDir)
                                                              .defaultValue("")
                                                              .extension("html"));
    }

    public View<Checkout> checkout() {
        return page("checkout");
    }

    public View<AvailableItems> items() {
        return page("items");
    }

    public View<Products> products() {
        return page("products");
    }

    public View<Cart> cart() {
        return page("cart");
    }

    public View<Void> home() {
        return page("home");
    }

    public View<Order> order() {
        return page("order");
    }

    private <T> View<T> page(final String named) {
        return (response, context) -> {
            response.contentType("text/html; charset=utf-8");
            Template<T> template = templates.named(named);
            response.done(template.render(context));
        };
    }
}
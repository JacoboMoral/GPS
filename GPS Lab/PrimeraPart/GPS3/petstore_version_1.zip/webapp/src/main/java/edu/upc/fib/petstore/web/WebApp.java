package edu.upc.fib.petstore.web;

import java.io.File;
import java.sql.Connection;
import java.util.ResourceBundle;

import com.vtence.molecule.Application;
import com.vtence.molecule.MiddlewareStack;
import com.vtence.molecule.Request;
import com.vtence.molecule.Response;
import com.vtence.molecule.middlewares.ConnectionScope;
import com.vtence.molecule.middlewares.FilterMap;
import com.vtence.molecule.middlewares.Layout;
import com.vtence.molecule.middlewares.Router;
import com.vtence.molecule.routing.DynamicRoutes;

import edu.upc.fib.petstore.db.ItemsDatabase;
import edu.upc.fib.petstore.db.JDBCTransactor;
import edu.upc.fib.petstore.db.OrderNumberDatabaseSequence;
import edu.upc.fib.petstore.db.OrdersDatabase;
import edu.upc.fib.petstore.db.ProductsDatabase;
import edu.upc.fib.petstore.order.Cashier;
import edu.upc.fib.petstore.order.OrderBook;
import edu.upc.fib.petstore.order.OrderNumberSequence;
import edu.upc.fib.petstore.procurement.ProcurementRequestHandler;
import edu.upc.fib.petstore.procurement.PurchasingAgent;
import edu.upc.fib.petstore.product.AttachmentStorage;
import edu.upc.fib.petstore.product.ItemInventory;
import edu.upc.fib.petstore.product.ProductCatalog;
import edu.upc.fib.petstore.transaction.Transactor;
import edu.upc.fib.petstore.web.controllers.CreateCartItem;
import edu.upc.fib.petstore.web.controllers.CreateItem;
import edu.upc.fib.petstore.web.controllers.CreateProduct;
import edu.upc.fib.petstore.web.controllers.ListItems;
import edu.upc.fib.petstore.web.controllers.ListProducts;
import edu.upc.fib.petstore.web.controllers.Logout;
import edu.upc.fib.petstore.web.controllers.PlaceOrder;
import edu.upc.fib.petstore.web.controllers.ProceedToCheckout;
import edu.upc.fib.petstore.web.controllers.ShowCart;
import edu.upc.fib.petstore.web.controllers.ShowOrder;
import edu.upc.fib.petstore.web.controllers.StaticView;
import edu.upc.fib.petstore.web.lib.BundledMessages;
import edu.upc.fib.petstore.web.lib.FileSystemPhotoStore;

public class WebApp implements Application {

    private final Pages pages;
    private final PageStyles styles;

    public WebApp(final File webRoot) {
        this.pages = new Pages(new File((WebRoot.locate() + File.separator + "src" + File.separator + "main" + File.separator + "content" + File.separator + "views" + File.separator + "pages").replace("server", "webapp")));
        this.styles = new PageStyles(new File((WebRoot.locate() + File.separator + "src" + File.separator + "main" + File.separator + "content" + File.separator + "views" + File.separator + "layouts").replace("server", "webapp")));
    }

    public void handle(final Request request, final Response response) throws Exception {
        final AttachmentStorage attachments = new FileSystemPhotoStore("/photos");
        final Connection connection = new ConnectionScope.Reference(request).get();
        final Transactor transactor = new JDBCTransactor(connection);
        final ProductCatalog products = new ProductsDatabase(connection);
        final ItemInventory items = new ItemsDatabase(connection);
        final ProcurementRequestHandler procurement = new PurchasingAgent(products, items, transactor);
        final OrderNumberSequence orderNumbers = new OrderNumberDatabaseSequence(connection);
        final OrderBook orders = new OrdersDatabase(connection);
        final Cashier cashier = new Cashier(orderNumbers, orders, transactor);
        final Messages messages = new BundledMessages(ResourceBundle.getBundle("ValidationMessages"));

        Router router = Router.draw(new DynamicRoutes() {{
            get("/products").to(new ListProducts(products, attachments, pages.products()));
            post("/products").to(new CreateProduct(procurement));
            get("/products/:product/items").to(new ListItems(items, pages.items()));
            post("/products/:product/items").to(new CreateItem(procurement));
            get("/cart").to(new ShowCart(pages.cart()));
            post("/cart").to(new CreateCartItem(items));
            get("/orders/new").to(new ProceedToCheckout(pages.checkout()));
            get("/orders/:number").to(new ShowOrder(orders, pages.order()));
            post("/orders").to(new PlaceOrder(cashier, pages.checkout(), messages));
            delete("/logout").to(new Logout());
            map("/").to(new StaticView(pages.home()));
        }});

        new MiddlewareStack() {{
            use(new FilterMap().map("/", Layout.html(new PageDecorator(styles.main()))));
            run(router);
        }}.handle(request, response);
    }
}

package edu.upc.fib.petstore.web;

import java.io.IOException;

import com.vtence.molecule.Response;

public interface View<T> {

    void render(Response response, T context) throws IOException;
}

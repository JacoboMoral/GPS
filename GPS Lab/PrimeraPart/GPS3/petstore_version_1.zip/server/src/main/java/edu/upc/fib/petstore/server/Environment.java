package edu.upc.fib.petstore.server;

import java.io.IOException;

import edu.upc.fib.petstore.web.lib.Configuration;

public final class Environment {

    private static final String FILE_LOCATION = "etc/%s.properties";

    public static Configuration test() throws IOException {
        return load("test");
    }

    public static Configuration load(String name) throws IOException {
        Configuration config = Configuration.load(String.format(FILE_LOCATION, name));
        config.merge(System.getProperties());
        return config;
    }
}

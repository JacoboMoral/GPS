package edu.upc.fib.petstore.server.actors.activities;

import edu.upc.fib.petstore.server.ScenarioContext;
import edu.upc.fib.petstore.server.drivers.ApplicationDriver;
import edu.upc.fib.petstore.server.drivers.pages.CartPage;
import edu.upc.fib.petstore.server.drivers.pages.CheckoutPage;
import edu.upc.fib.petstore.server.features.Item;

public class Ordering {
    private final ApplicationDriver application;
    private final ScenarioContext context;

    public Ordering(ApplicationDriver application, ScenarioContext context) {
        this.application = application;
        this.context = context;
    }

    public Ordering addToCart(String productName, String itemNumber) {
        application.search(productName).selectProduct(productName).addToCart(itemNumber);
        return this;
    }

    public Ordering seesTotalToPay(String amount) {
        application.openCart().checkout().showsTotalToPay(amount).continueShopping();
        return this;
    }

    public void seesCartContent(String totalPrice, Item... items) {
        CartPage cartPage = application.openCart();
        cartPage.showsGrandTotal(totalPrice);
        for (Item item : items) {
            cartPage.showsItem(item.number, item.description, item.price, item.quantity, item.totalPrice);
        }
    }

      

   
}
package edu.upc.fib.petstore.server.features;

import static edu.upc.fib.petstore.server.features.Item.item;

import java.io.IOException;

import org.junit.Test;

public class CartFeature extends BaseFeature {


    @Test
    public void
    shoppingForItemsAndAddingThemToOurCart() throws IOException {
        administrator.addProductToCatalog("LIZ-0001", "Iguana", "Big lizard", "iguana.png");
        administrator.addItemToInventory("LIZ-0001", "12345678", "Green Adult", "18.50");
        administrator.addItemToInventory("LIZ-0001", "87654321", "Blue Female", "58.97");

        customer.loginAs("joe")
                .seesCartIsEmpty();

        customer.startShopping()
                .addToCart("Iguana", "12345678")
                .seesCartContent("18.50", item("12345678", "Green Adult", "18.50"));
        customer.seesCartTotalQuantity(1);

        customer.continueShopping()
                .addToCart("Iguana", "87654321")
                .seesCartContent("77.47",
                        item("12345678", "Green Adult", "18.50"),
                        item("87654321", "Blue Female", "58.97"));
        customer.seesCartTotalQuantity(2);

        customer.continueShopping()
                .addToCart("Iguana", "12345678")
                .seesCartContent("95.97",
                        item("12345678", "Green Adult", "18.50", 2, "37.00"),
                        item("87654321", "Blue Female", "58.97"));
        customer.seesCartTotalQuantity(3);
    }
}

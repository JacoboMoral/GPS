package edu.upc.fib.petstore.server.drivers.browsers;

import org.openqa.selenium.WebDriver;

public interface Browser {

    WebDriver launch();
}

package edu.upc.fib.petstore.server.actors;

import java.io.IOException;

import edu.upc.fib.petstore.server.actors.activities.StoreManagement;
import edu.upc.fib.petstore.server.drivers.APIDriver;

public class Administrator {

    private final APIDriver api;

    public Administrator(APIDriver api) {
        this.api = api;
    }

    public void addProductToCatalog(String number, String name, String description, String photo) throws IOException {
        manageStore().addProduct(number, name, description, photo);
    }

    public void addItemToInventory(String productNumber, String itemNumber, String itemDescription, String itemPrice) throws IOException {
        manageStore().addItem(productNumber, itemNumber, itemDescription, itemPrice);
    }

    public StoreManagement manageStore() {
        return new StoreManagement(api);
    }
}
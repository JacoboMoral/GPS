package edu.upc.fib.petstore.server.actors;

import edu.upc.fib.petstore.server.ScenarioContext;
import edu.upc.fib.petstore.server.actors.activities.Ordering;
import edu.upc.fib.petstore.server.drivers.ApplicationDriver;

public class Customer {

    private final ScenarioContext context;
    private final ApplicationDriver application;

    public Customer(ScenarioContext context, ApplicationDriver application) {
        this.context = context;
        this.application = application;
    }

    public void done() {
        application.logout().leave();
    }

    public Customer loginAs(String username) {
        application.enter().loginAs(username);
        return this;
    }

    public Customer seesCartIsEmpty() {
        application.displaysCartItemCount(0);
        return this;
    }

    public Customer seesCartTotalQuantity(int quantity) {
        application.displaysCartItemCount(quantity);
        return this;
    }

    public Ordering startShopping() {
        application.enter();
        return new Ordering(application, context);
    }

    public Ordering continueShopping() {
        return new Ordering(application, context);
    }


}
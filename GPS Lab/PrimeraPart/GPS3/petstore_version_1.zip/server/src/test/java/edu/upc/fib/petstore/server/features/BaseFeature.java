package edu.upc.fib.petstore.server.features;

import org.junit.After;
import org.junit.Before;

import edu.upc.fib.petstore.server.Actors;
import edu.upc.fib.petstore.server.actors.Administrator;
import edu.upc.fib.petstore.server.actors.Customer;
import edu.upc.fib.petstore.server.drivers.ServerDriver;

/**
 * Created by guillemhernandezsola on 26/10/2016.
 */
public class BaseFeature {
    ServerDriver server = new ServerDriver();
    Actors actors = new Actors();
    Administrator administrator = actors.administrator();
    Customer customer = actors.customer();

    @Before
    public void
    setUp() throws Exception {
        server.start();
    }

    @After
    public void
    tearDown() throws Exception {
        server.stop();
    }

    @After
    public void
    stopUsingApplication() {
        customer.done();
    }
}

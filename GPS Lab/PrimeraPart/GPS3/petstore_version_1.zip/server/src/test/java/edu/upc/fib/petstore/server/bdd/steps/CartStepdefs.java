package edu.upc.fib.petstore.server.bdd.steps;

import static edu.upc.fib.petstore.server.features.Item.item;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import edu.upc.fib.petstore.server.Actors;
import edu.upc.fib.petstore.server.actors.Administrator;
import edu.upc.fib.petstore.server.actors.Customer;
import edu.upc.fib.petstore.server.drivers.ServerDriver;

public class CartStepdefs {

    ServerDriver server = new ServerDriver();
    Actors actors = new Actors();
    Administrator administrator = actors.administrator();
    Customer customer = actors.customer();

    @Given("^products and items on catalog and on inventory$")
    public void products_and_items_on_catalog_and_on_inventory() throws Throwable {
        server.start();
        administrator.addProductToCatalog("LIZ-0001", "Iguana", "Big lizard", "iguana.png");
        administrator.addItemToInventory("LIZ-0001", "12345678", "Green Adult", "18.50");
        administrator.addItemToInventory("LIZ-0001", "87654321", "Blue Female", "58.97");
    }

    @When("^a user is logged as Joe$")
    public void a_user_is_logged_as_Joe() throws Throwable {
        customer.loginAs("joe")
                .seesCartIsEmpty();
    }

    @Then("^Joe can add Iguanas to the cart and check if the Iguanas are added into the shopping cart$")
    public void Joe_can_Iguanas_to_the_cart_and_check_if_the_Iguanas_are_added_into_the_shopping_cart() throws Throwable {
        customer.startShopping()
                .addToCart("Iguana", "12345678")
                .seesCartContent("18.50", item("12345678", "Green Adult", "18.50"));
        customer.seesCartTotalQuantity(1);

        customer.continueShopping()
                .addToCart("Iguana", "87654321")
                .seesCartContent("77.47",
                        item("12345678", "Green Adult", "18.50"),
                        item("87654321", "Blue Female", "58.97"));
        customer.seesCartTotalQuantity(2);

        customer.continueShopping()
                .addToCart("Iguana", "12345678")
                .seesCartContent("95.97",
                        item("12345678", "Green Adult", "18.50", 2, "37.00"),
                        item("87654321", "Blue Female", "58.97"));
        customer.seesCartTotalQuantity(3);
        server.stop();
        customer.done();
    }
}

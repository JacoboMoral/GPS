package edu.upc.fib.petstore.server.bdd;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * Created by guillemhernandezsola on 28/10/2016.
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = {"src/test/resources/Cart.feature"}, glue = "edu.upc.fib.petstore.server.bdd.steps", strict = true, format = {
        "pretty", "html:target/cucumber", "json:target/Cucumber.json"})
public class CartTest {


}

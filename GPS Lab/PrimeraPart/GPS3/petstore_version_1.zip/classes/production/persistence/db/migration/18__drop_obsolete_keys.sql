alter table items drop key reference_number;
alter table orders drop key number_2;
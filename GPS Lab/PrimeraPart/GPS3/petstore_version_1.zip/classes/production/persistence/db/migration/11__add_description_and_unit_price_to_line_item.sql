alter table line_items add column item_description text;
alter table line_items add column item_unit_price decimal(10,2) not null;
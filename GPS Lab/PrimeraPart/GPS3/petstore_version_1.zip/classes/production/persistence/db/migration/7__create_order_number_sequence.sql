create table order_number_sequence (
  next_value bigint(20) unsigned not null primary key auto_increment
) engine = MyISAM; 

alter table items add column description text;
alter table items add column price decimal(10,2) not null;
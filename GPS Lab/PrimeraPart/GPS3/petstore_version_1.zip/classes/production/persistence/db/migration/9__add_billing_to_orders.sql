alter table orders add column billing_first_name varchar(255);
alter table orders add column billing_last_name varchar(255);
alter table orders add column billing_email varchar(255);
alter table orders add column credit_card_type varchar(255);
alter table orders add column credit_card_number varchar(255);
alter table orders add column credit_card_expiry_date varchar(255);
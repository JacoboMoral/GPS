create table products (
  id bigint(20) unsigned not null auto_increment,
  name varchar(255) not null,
  primary key(id)
) engine=InnoDB;